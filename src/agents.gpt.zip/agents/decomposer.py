
import json
import re

from langchain_core.messages import HumanMessage, SystemMessage
from pydantic import ValidationError

from src.llm.llm import get_llm
from src.schemas import DecompositionOutput, Understanding


SYSTEM_PROMPT = """
You are an expert digital hardware architect specializing in
RTL design and hardware specification decomposition.

Your task is to convert the supplied hardware specification
understanding into a logically connected, synthesizable hardware architecture.

Use ONLY the information provided in the understanding.
Do not invent external signals, operations, timing requirements,
or hardware behavior.

Return exactly one valid JSON object containing:
- components
- interactions
- implementation_plan

==================================================
1. COMPONENT DECOMPOSITION
==================================================

Identify the essential hardware components required by the specification.
Derive components from the explicitly identified functional groupings or
major components in the understanding.

General Decomposition Principles:
- Every component must have a clear, distinct hardware responsibility.
- Do not combine fundamentally separate responsibilities into one monolithic block.
- Do not invent artificial physical modules when the specification does not warrant them.
- Do not create fixed architecture templates for FSM, arithmetic, datapath,
  timer, sensor, protocol, memory, or control designs.
- Create physical components only when the specification or a clearly
  justified functional grouping supports separate responsibilities.

==================================================
2. COMPONENT INTERFACES
==================================================

Every component in 'components' must contain exactly:
- name: string
- purpose: string
- inputs: list of strings
- outputs: list of strings

CRITICAL INTERFACE RULES:
1. EXTERNAL SIGNALS MUST REMAIN EXTERNAL:
   - External inputs from the understanding remain external signals driving
     the components that need them.
   - NEVER create an internal component that generates or outputs an external input!
     If a specification names timer, sensor, clock, or control inputs as external,
     preserve them as external inputs and do not add an internal source component.
2. NO ARTIFICIAL INTERMEDIATE SIGNALS:
   - Do NOT invent intermediate signals or interfaces that rename or replace external inputs
     (for example, do not invent a renamed detected/input_ready signal when the
     specification names a signal directly).
   - If an Understanding input is an external timer, sensor, clock, reset, or
     control signal, keep the exact external name and do not create another
     component that generates or renames it.
3. OUTPUT DRIVERS:
   - Every external output defined in the understanding must be driven by exactly one component.
4. EXACT NAMES AND WIDTHS:
   - Preserve signal names and bit widths exactly as established by the specification.

==================================================
3. SIGNAL OWNERSHIP & CONNECTIONS
==================================================

- Each signal must have exactly one source/driver.
- Never declare the same signal as an output of multiple components.
- Never make a component consume its own output.
- Never create circular combinational dependencies or self-connections.
- Every internal connection must connect an existing component output to an existing component input.

==================================================
4. CLOCK AND RESET
==================================================

- Add clock or reset ports only when the understanding explicitly names
  them or the assigned responsibility clearly requires the stated clock/reset
  behavior.
- Do not infer clock, reset type, reset polarity, reset value, or reset
  connectivity from the fact that a component is sequential.
- Combinational components must not receive clock or reset ports unless the
  original specification requires them for that component.
- Follow the reset polarity and behavior specified in the understanding.
- If reset polarity or type is not specified in the understanding, do NOT guess active-low or
  active-high; represent it faithfully.

==================================================
5. INTERACTIONS
==================================================

Return 'interactions' as an ARRAY OF STRINGS.
Format each interaction as:
"<source_signal> -> <destination_component> <destination_port>"
or
"<source_component> <source_port> -> <destination_component> <destination_port>"

Every connection must match the declared component interfaces.

==================================================
6. IMPLEMENTATION PLAN
==================================================

Return 'implementation_plan' as an ARRAY OF OBJECTS.
Each object must contain exactly:
{
    "step_number": integer,
    "title": string,
    "description": string
}

Order the steps logically from basic interface and reset setup, to core functional
and state logic, status reporting, and top-level integration.

==================================================
7. OUTPUT FORMAT
==================================================

Return valid JSON only.
Do not return Markdown code fences or explanations outside the JSON.
Use exactly the top-level keys:
- components
- interactions
- implementation_plan

Ensure the output conforms strictly to the DecompositionOutput schema.
"""


def _normalize_response_content(content) -> str:
    if isinstance(content, str):
        return content

    if isinstance(content, list):
        text_parts = [
            item.get("text", "")
            for item in content
            if isinstance(item, dict) and item.get("type") == "text"
        ]
        if text_parts:
            return "".join(text_parts).strip()

    raise ValueError(
        "Decomposer Agent returned invalid output: "
        "response content is not text."
    )


def _extract_json(content) -> dict:
    """
    Extract and parse the JSON response from the LLM.
    Handles optional Markdown JSON code fences.
    """

    content = _normalize_response_content(content).strip()

    # Remove optional Markdown code fences.
    content = re.sub(
        r"^```(?:json)?\s*",
        "",
        content,
        flags=re.IGNORECASE
    )

    content = re.sub(r"\s*```$", "", content)

    try:
        parsed_result = json.loads(content)

    except json.JSONDecodeError as exc:
        raise ValueError(
            "Decomposer Agent returned invalid JSON: "
            f"{exc.msg} at line {exc.lineno}, column {exc.colno}"
        ) from exc

    # Handle a single JSON object wrapped in a list.
    if isinstance(parsed_result, list):

        if len(parsed_result) == 1:
            parsed_result = parsed_result[0]

        elif not parsed_result:
            raise ValueError(
                "Decomposer Agent returned an empty list "
                "instead of a decomposition dictionary."
            )

        else:
            raise ValueError(
                "Decomposer Agent returned multiple JSON objects "
                "instead of a single decomposition dictionary."
            )

    if not isinstance(parsed_result, dict):
        raise ValueError(
            "Decomposer Agent returned an unsupported JSON root type: "
            f"{type(parsed_result).__name__}"
        )

    return parsed_result


def _is_retryable_truncated_response(error: Exception) -> bool:
    error_name = type(error).__name__
    error_text = str(error).lower()
    return (
        "LengthFinishReasonError" in error_name
        or "length limit was reached" in error_text
        or "finish reason was length" in error_text
    )


def decomposer(understanding: Understanding) -> DecompositionOutput:

    # Convert the understanding into JSON.
    understanding_json = understanding.model_dump_json(indent=2)

    # Initialize the LLM.
    llm = get_llm("decomposer")

    external_names = {
        signal.split("[", 1)[0].strip().lower()
        for signal in understanding.inputs
        if signal.strip() and not signal.upper().startswith("NOT SPECIFIED:")
    }

    feedback = ""
    for attempt in range(1, 3):
        retry_feedback = ""
        if feedback:
            retry_feedback = (
                "\nDETERMINISTIC ARCHITECTURE REJECTION FROM THE PREVIOUS OUTPUT:\n"
                f"{feedback}\n"
                "Regenerate the entire decomposition and preserve all external inputs "
                "without creating source or renaming components.\n"
            )

        try:
            response = llm.invoke([
                SystemMessage(content=SYSTEM_PROMPT),
                HumanMessage(
                    content=(
                        "Decompose the following hardware specification "
                        "understanding into a valid hardware architecture.\n\n"
                        f"{understanding_json}"
                        f"{retry_feedback}"
                    )
                )
            ])
        except Exception as error:
            print("\nDecomposer model invocation failed:")
            print(f"{type(error).__name__}: {error}")
            if _is_retryable_truncated_response(error) and attempt < 2:
                feedback = (
                    "The previous response was truncated at the completion limit. "
                    "Return a complete, smaller valid JSON object."
                )
                continue
            raise

        print("\n========== RAW DECOMPOSITION RESPONSE ==========")
        print(response.content)

        try:
            parsed_result = _extract_json(response.content)
        except ValueError as error:
            print("\nDecomposer response parsing failed:")
            print(error)
            if attempt < 2:
                feedback = (
                    "The previous response was incomplete or invalid JSON. "
                    "Regenerate exactly one complete valid JSON object with "
                    "only components, interactions, and implementation_plan."
                )
                continue
            raise

        print("\n========== PARSED DECOMPOSITION ==========")
        print(json.dumps(parsed_result, indent=2))

        try:
            result = DecompositionOutput.model_validate(parsed_result)
        except ValidationError as exc:
            print("\nDecomposer response schema validation failed:")
            print(exc)
            if attempt < 2:
                feedback = (
                    "The previous JSON did not match the DecompositionOutput schema. "
                    "Regenerate exactly one complete object with every component "
                    "containing name, purpose, inputs, and outputs."
                )
                continue
            raise ValueError(
                "Decomposer Agent returned JSON that does not match "
                "the DecompositionOutput schema:\n"
                f"{exc}"
            ) from exc

        violations = []
        for component in result.components:
            component_name = component.name.lower()
            for external_name in external_names:
                if (
                    external_name in component_name
                    and any(term in component_name for term in ("timer", "sensor"))
                ):
                    violations.append(
                        f"Component {component.name} appears to source or manage "
                        f"external signal {external_name}; do not create internal "
                        "components for external timer/sensor inputs"
                    )
            for output in component.outputs:
                output_name = output.split("[", 1)[0].strip().lower()
                if output_name in external_names:
                    violations.append(
                        f"Component {component.name} outputs external input "
                        f"{output}; external inputs must remain top-level inputs"
                    )

        if violations:
            feedback = "\n".join(f"- {item}" for item in violations)
            print("\nDecomposer architecture validation failed:")
            print(feedback)
            if attempt == 2:
                raise ValueError(
                    "Decomposer Agent created components that source external "
                    "inputs: " + "; ".join(violations)
                )
            continue

        print("\nDecomposer Agent output validated successfully.")
        return result

    raise ValueError("Decomposer Agent did not produce a valid architecture.")
