from src.llm.llm import get_llm
from src.schemas import DescriptionOutput


def reflect_description(
    specification: str,
    description: DescriptionOutput,
    issues: list[str],
    component=None,
    interactions: list[str] | None = None,
) -> DescriptionOutput:

    llm = get_llm()

    reflection_llm = llm.with_structured_output(
        DescriptionOutput
    )

    component_context = (
        component.model_dump_json(indent=2)
        if component is not None
        else "Not provided."
    )

    interaction_context = (
        "\n".join(f"- {item}" for item in interactions)
        if interactions
        else "Not provided."
    )

    prompt = f"""
You are the Reflection Agent in the SPEC2RTL pipeline.

Your task is to correct a component description that failed verification.

ORIGINAL HARDWARE SPECIFICATION:
{specification}

COMPONENT DEFINITION FROM DECOMPOSER:
{component_context}

COMPONENT INTERACTIONS:
{interaction_context}

CURRENT COMPONENT DESCRIPTION:
{description.model_dump_json(indent=2)}

VERIFICATION ISSUES:
{issues}

RULES:
1. Preserve the component's original responsibility.
2. Fix the identified issues without redesigning the entire system.
3. Do not turn a subcomponent into the complete top-level design.
4. Preserve the component's defined inputs and outputs unless the
   verification issues establish that they are incorrect.
5. Do not invent signal names, widths, constraints, or behaviors.
6. Preserve correct information.
7. If an issue cannot be resolved from the supplied evidence,
   do not invent a solution.
8. Return the complete corrected DescriptionOutput.

Return structured output only.
"""

    return reflection_llm.invoke(prompt)