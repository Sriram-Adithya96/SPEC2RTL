
import json
import re

from langchain_core.messages import HumanMessage, SystemMessage
from pydantic import ValidationError

from src.llm.llm import get_llm, is_free_openrouter_model
from src.schemas import DescriptionOutput, VerificationResult

try:
    from langchain.agents import create_agent
except ImportError:
    def create_agent(*args, **kwargs):
        pass


def create_verification_agent():
    """Create the tool-free Verification Agent."""
    return create_agent(
        model=get_llm("verification"),
        tools=[],
        system_prompt=SYSTEM_PROMPT,
        response_format=None if is_free_openrouter_model("verification") else VerificationResult,
    )


def _normalize_verification_response_content(content) -> str:
    if isinstance(content, str):
        text = content
    elif isinstance(content, list):
        text_parts = []
        for block in content:
            if isinstance(block, dict) and block.get("type") == "text":
                text_parts.append(block.get("text", ""))
            elif isinstance(block, str):
                text_parts.append(block)
        text = "".join(text_parts)
    else:
        raise ValueError(
            "Verification Agent returned invalid output: "
            "response content is not text."
        )

    text = text.strip()
    if not text:
        raise ValueError("Verification Agent returned empty response content.")
    return text


def _extract_verification_json(content) -> dict:
    response_json = _normalize_verification_response_content(content)

    if response_json.startswith("```"):
        response_json = re.sub(
            r"^```(?:json)?\s*",
            "",
            response_json,
            count=1,
            flags=re.IGNORECASE,
        )
        if response_json.endswith("```"):
            response_json = response_json[:-3].strip()

    if not response_json.startswith("{"):
        start = response_json.find("{")
        end = response_json.rfind("}")
        if start != -1 and end != -1:
            response_json = response_json[start:end + 1]

    try:
        return json.loads(response_json)
    except json.JSONDecodeError as exc:
        raise ValueError(
            "Verification Agent returned invalid JSON: "
            f"{exc.msg} at line {exc.lineno}, column {exc.colno}"
        ) from exc


SYSTEM_PROMPT = """
You are the Verification Agent in the SPEC2RTL system.

Your task is to verify a component description using:
1. The original hardware specification.
2. The component definition from the Decomposer Agent.
3. The architecture interactions between components.
4. The component description from the Description Agent.

IMPORTANT ARCHITECTURE RULES:

- The original specification describes the complete hardware system.
- The Decomposer defines the interface and responsibility of each internal component.
- Verify a component against its own Decomposer definition.
- Never require a subcomponent to expose every top-level system signal.
- Never invent inputs, outputs, registers, or responsibilities.
- Do not confuse the responsibilities of different components.

VERIFICATION CHECKLIST:

1. COMPONENT RESPONSIBILITY
   - Does the component perform the responsibility assigned by the Decomposer?
   - Does it avoid taking responsibility assigned to another component?

2. INTERFACE
   - Check inputs and outputs against the Decomposer definition.
   - Do not report an interface problem if the interfaces match.
   - Do not invent additional signals.

3. STATE ELEMENTS
   - Check whether the listed state elements are appropriate for the component.
   - A combinational component should not claim clocked registers.
   - Sequential components should describe their required storage and reset behavior.

4. BEHAVIOR
   - Compare the description against the original specification.
   - Check for missing essential behavior and contradictions.
   - Do not mark a component invalid for optional implementation details that the specification does not require.

5. ARCHITECTURE INTERACTIONS
   - Check whether the component's inputs and outputs are consistent with the supplied interactions.
   - Do not assume connections that are not provided.

GENERAL VERIFICATION GUIDELINES:
- For FSM controllers: Verify state transition conditions, reset behavior, and control signal generation.
- For combinational data processing (ALUs, decoders): Verify operation mappings, bit widths, and that no unneeded clocked state elements are claimed.
- For sequential registers / capture units: Verify storage, write enables, and reset behavior.
- Reset polarity & type: Do NOT require active-low or active-high reset unless explicitly stated in the specification evidence. If unspecified, accepting 'not specified' or 'implementation-defined' is correct.


IMPORTANT STATE ELEMENT VALIDATION:

- The Decomposer defines component responsibilities and interfaces.
  It does not necessarily define every internal state element.

- Do not reject a state element merely because it is not explicitly
  listed in the Decomposer definition.
- Sequential state elements are appropriate only when storage, sequencing,
  synchronization, or clocked behavior is supported by the original
  specification.
- Combinational components should not claim clocked state merely from
  architectural conventions.

- Set valid=false only when state elements contradict the original
  specification or the component's actual responsibility.
- Do not assume that a component must be combinational unless
  the specification and architecture require it.

VALIDATION DECISIONS:

- Set valid=false for genuine contradictions, interface mismatches,
  or missing essential behavior.
- Set valid=true when no significant contradiction or missing requirement is found.
- Do not reject a component based only on missing optional details.
- List actual issues, not vague observations.
- Suggestions must explain how to correct the identified issues.
- Reasoning must briefly explain what was checked and any limitations.
- Do not claim that behavior was simulated or tested. This is static textual review only.

Return ONLY valid JSON with exactly these fields:

{
    "valid": true,
    "issues": [],
    "suggestions": [],
    "reasoning": "Explanation"
}
"""


def check_interface_consistency(component, description: DescriptionOutput):
    """
    Compare description inputs and outputs against the Decomposer definition.
    Returns (is_consistent, issues).
    """

    if component is None:
        return True, []

    def clean(signal):
        return signal.split("[")[0].strip()

    comp_in = [clean(signal) for signal in component.inputs]
    comp_out = [clean(signal) for signal in component.outputs]

    desc_in = [clean(signal.name) for signal in description.inputs]
    desc_out = [clean(signal.name) for signal in description.outputs]

    issues = []

    missing_in = set(comp_in) - set(desc_in)
    extra_in = set(desc_in) - set(comp_in)

    missing_out = set(comp_out) - set(desc_out)
    extra_out = set(desc_out) - set(comp_out)

    if missing_in:
        issues.append(
            f"Missing input(s) defined by Decomposer: {sorted(missing_in)}"
        )

    if extra_in:
        issues.append(
            f"Extra input(s) not defined by Decomposer: {sorted(extra_in)}"
        )

    if missing_out:
        issues.append(
            f"Missing output(s) defined by Decomposer: {sorted(missing_out)}"
        )

    if extra_out:
        issues.append(
            f"Extra output(s) not defined by Decomposer: {sorted(extra_out)}"
        )

    if len(desc_in) != len(set(desc_in)):
        issues.append("Duplicate input signals found in component description.")

    if len(desc_out) != len(set(desc_out)):
        issues.append("Duplicate output signals found in component description.")

    return len(issues) == 0, issues


def check_reset_evidence(
    source_chunks: list,
    description: DescriptionOutput,
) -> list[str]:
    source = "\n\n".join(doc.page_content for doc in source_chunks).lower()
    claimed_parts = []
    for state_element in description.state_elements:
        claimed_parts.append(state_element.reset_value)
        claimed_parts.append(state_element.description)
    claimed_parts.extend(description.constraints)
    claimed_parts.extend(description.behavior)
    claimed = "\n".join(claimed_parts).lower()

    issues = []
    evidence_by_phrase = {
        "active-low": "active-low" in source,
        "active-high": "active-high" in source,
        "asynchronous reset": (
            "asynchronous" in source and "reset" in source
        ),
        "synchronous reset": (
            "synchronous" in source and "reset" in source
        ),
    }
    for phrase, supported in evidence_by_phrase.items():
        if phrase in claimed and not supported:
            issues.append(
                f"Unsupported reset claim '{phrase}' is not established "
                "by the original specification."
            )
    return issues


def verify_description(
    source_chunks: list,
    description: DescriptionOutput,
    component=None,
    interactions: list[str] | None = None,
) -> VerificationResult:
    """
    Verify a component description against the original specification
    and its Decomposer definition.
    """

    # Step 1: Perform deterministic interface validation.
    is_interface_valid, interface_issues = check_interface_consistency(
        component,
        description
    )
    reset_issues = check_reset_evidence(source_chunks, description)
    deterministic_issues = interface_issues + reset_issues
    deterministic_valid = is_interface_valid and not reset_issues

    # Step 2: Collect original specification text.
    specifications = "\n\n".join(
        doc.page_content for doc in source_chunks
    )

    # Step 3: Collect component definition.
    component_context = (
        component.model_dump_json(indent=2)
        if component is not None
        else "Not provided."
    )

    # Step 4: Collect architecture interactions.
    interaction_context = (
        "\n".join(f"- {item}" for item in interactions)
        if interactions
        else "Not provided."
    )

    # Step 5: Prepare interface validation information.
    interface_status = (
        "PASS: Inputs and outputs match the Decomposer definition."
        if is_interface_valid
        else "FAIL:\n" + "\n".join(interface_issues)
    )
    if reset_issues:
        interface_status += (
            "\nRESET EVIDENCE FAIL:\n"
            + "\n".join(reset_issues)
        )

    # Step 6: Prepare verification prompt.
    prompt = f"""
Verify the following component description.

ORIGINAL HARDWARE SPECIFICATION:
{specifications}

DECOMPOSER COMPONENT DEFINITION:
{component_context}

ARCHITECTURE INTERACTIONS:
{interaction_context}

COMPONENT DESCRIPTION:
{description.model_dump_json(indent=2)}

DETERMINISTIC INTERFACE VALIDATION:
{interface_status}

VERIFICATION TASKS:

1. Check whether the component responsibility matches its Decomposer definition.

2. Check whether the state elements are appropriate for its responsibility.

3. Check whether the behavior satisfies the relevant requirements in the
   original hardware specification.

4. Check timing, reset behavior, and operation sequencing wherever applicable.

5. Check whether the component's responsibilities overlap incorrectly
   with another component.

6. Check whether the described behavior is consistent with the supplied
   architecture interactions.

7. Identify only genuine contradictions and missing essential requirements.

8. STATE ELEMENT RULES:

- Do not require state elements to be explicitly listed by the Decomposer.
- Purely combinational modules (e.g. ALUs, combinational decoders) should have empty state elements [].
- Sequential modules (e.g. FSM controllers, registers) are expected to describe their state elements.
- Reject state elements only when they contradict the hardware specification
  or the component's assigned responsibility.

IMPORTANT:
- The deterministic interface validation above is authoritative.
- If it reports FAIL, the final result must be valid=false.
- If it reports PASS, do not invent interface mismatch issues.
- Do not reject a component because it does not expose unrelated top-level signals.
- Do not assume that a requirement belongs to this component unless its
  responsibility or interface supports that requirement.
- This is static textual verification, not RTL simulation.

Return only this JSON structure:

{{
    "valid": true,
    "issues": [],
    "suggestions": [],
    "reasoning": "Explain the checks performed and their results."
}}
"""

    # Step 7: Free OpenRouter models use a direct LLM call. Do not invoke
    # an unstructured agent first and then make a second LLM call as fallback.
    if not is_free_openrouter_model("verification"):
        agent = create_verification_agent()
        if agent and hasattr(agent, "invoke"):
            agent_res = agent.invoke(
                {"messages": [{"role": "user", "content": prompt}]}
            )
            if isinstance(agent_res, dict) and "structured_response" in agent_res:
                verification = agent_res["structured_response"]
                if isinstance(verification, dict):
                    verification = VerificationResult.model_validate(verification)
                if not deterministic_valid:
                    verification.valid = False
                    verification.issues = (
                        deterministic_issues
                        + [
                            issue
                            for issue in verification.issues
                            if issue not in deterministic_issues
                        ]
                    )
                    verification.suggestions = (
                        verification.suggestions
                        + ["Correct the component inputs and outputs to match the Decomposer definition."]
                    )
                return verification

            raise ValueError(
                "Verification Agent did not return a structured_response. "
                "No second LLM call was made."
            )

    # Free models return plain text, so parse one direct response.
    llm = get_llm("verification")
    response = llm.invoke([
        SystemMessage(content=SYSTEM_PROMPT),
        HumanMessage(content=prompt)
    ])

    # Step 8: Normalize, clean, and parse the model response.
    try:
        parsed_result = _extract_verification_json(response.content)
    except ValueError as exc:
        metadata = getattr(response, "response_metadata", None)
        usage = getattr(response, "usage_metadata", None)
        raise ValueError(
            f"{exc} Response metadata: {metadata!r}; usage metadata: {usage!r}"
        ) from exc
    # Step 10: Validate the output schema.
    try:
        verification = VerificationResult.model_validate(parsed_result)

    except ValidationError as exc:
        raise ValueError(
            "Verification Agent returned JSON that does not match "
            f"VerificationResult schema: {exc}"
        ) from exc

    # Step 11: Enforce deterministic interface validation.
    if not deterministic_valid:
        verification.valid = False

        verification.issues = (
            deterministic_issues
            + [
                issue
                for issue in verification.issues
                if issue not in deterministic_issues
            ]
        )

        verification.suggestions = (
            verification.suggestions
            + [
                "Correct the component inputs and outputs to match "
                "the Decomposer definition."
            ]
        )

    return verification
